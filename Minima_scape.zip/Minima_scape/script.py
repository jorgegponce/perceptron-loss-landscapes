#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Dec 11 15:12:25 2023

@author: HP
"""
import pickle 
from perceptron import NativePerceptron
import pennylane as qml
import pennylane.numpy as np
import jax
import jax.numpy as jnp
import optax
from perceptron import NativePerceptron
import time 

Ntrials=100
N=4
P=5*N

def set_data():
    final_thetas = np.zeros([Ntrials, 2*P*N])
    final_hessians = np.zeros([Ntrials, 2*P*N, 2*P*N])
    final_grad_norm = np.zeros([Ntrials])
    final_loss = np.zeros([Ntrials])
    for trial in range(1,Ntrials+1):
       to_files='../Hessian_Scaling/'+str(N)+'_qubits/'+str(P)+'_pulses/'+str(trial)+'/'
       file = str(P)+'_pulses_simulation_data.pickle'
       with open(to_files+file, 'rb') as infile: 
           data = pickle.load(infile)
       final_thetas[trial-1]=data['final_parameters']
       final_grad_norm[trial-1]=data["gradient_norms"][-1]
       final_hessians[trial-1]=data['final_hessian']
       final_loss[trial-1]=data['energies'][-1]
     
    final_data = {'final_thetas': final_thetas,
                  'final_grad_norm': final_grad_norm, 
                    'final_hessians': final_hessians,
                    'final_loss': final_loss}
    ofile='Final_results_N'+str(N)+'Pulses_'+str(P)+'.pt'
    with open(ofile, 'wb') as out:
        pickle.dump(final_data, out)
    return

#set_data()

file='Final_results_N'+str(N)+'Pulses_'+str(P)+'.pt'
with open(file, 'rb') as infile:
    data = pickle.load(infile)

#Setting jump parameters
initial_losses = data['final_loss']
eta = 0.01
gamma=0.55
# Configuration settings
jax.config.update("jax_enable_x64", True)
jax.config.update("jax_platform_name", "cpu")

# Setting up the quantum perceptron problem
perceptron_qubits = N
n_axis=2
pulse_basis = P
sigma=0.005
save_path = ''
n_epochs = 100

ts = jnp.array([1.0])
t = 1
times = jnp.linspace(0,t, pulse_basis+2)[1:-1]
dev = qml.device("default.qubit.jax", wires=perceptron_qubits)

#Setting up perceptron
perceptron = NativePerceptron(perceptron_qubits, pulse_basis, basis='gaussian', pulse_width=sigma, native_coupling=1)
H = perceptron.H

#Setting up target unitary
H_obj = perceptron.get_toy_model(0.1)
W = qml.evolve(H_obj, coeff=1)

hcs = [qml.PauliX(n) for n in range(perceptron_qubits)]
hcs+= [qml.PauliY(n) for n in range(perceptron_qubits)]
# Defining the loss function
@jax.jit
def loss(param_vector):
    param_list = perceptron.vector_to_hamiltonian_parameters(param_vector)
    U = qml.matrix(qml.evolve(perceptron.H)(param_list, t))
    return qml.math.frobenius_inner_product(jnp.conjugate(U-qml.matrix(W)), U-qml.matrix(W)).real

Nreps=5
indexes=[i for i in range(Ntrials) if initial_losses[i]>10**(-3)]

for ind in range(len(indexes)):
    trial = indexes[ind]
    schedule = optax.exponential_decay(0.1,n_epochs,0.1)
    
    optimizer = optax.adam(learning_rate=schedule)
    initial_loss = initial_losses[ind]
    
    for j in range(Nreps):
        #param_vector = data["final_thetas"][ind]
        random_seed = int(time.time() * 1000)  # time in milliseconds
        param_vector = perceptron.get_random_parameter_vector(random_seed)
        opt_state = optimizer.init(param_vector)
        sub_losses = np.zeros([n_epochs])
        gradient_diffs = np.zeros([n_epochs])
        gradients_trajectory = []
        
        # Optimization loop
        for n in range(n_epochs):
            val, grads = jax.value_and_grad(loss)(param_vector)
            updates, opt_state = optimizer.update(grads, opt_state)

            sub_losses[n] = val
                
            gradients_trajectory.append(grads)
            if n > 0:
                gradient_diffs[n - 1] = jnp.linalg.norm(grads - gradients_trajectory[-2])
            param_vector = optax.apply_updates(param_vector, updates)

            if n % 1 == 0:  # Adjust the frequency of printing as needed
                print(f"Epoch {n+1}/{n_epochs}; loss: {val}")
                if n > 0:
                    if val<initial_loss:
                        print("Doing better!")
                    else:
                        print("Doing worse :( ")