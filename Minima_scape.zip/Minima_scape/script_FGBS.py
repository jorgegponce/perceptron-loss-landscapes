#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Dec 11 15:12:25 2023

@author: HP
"""
import pickle 
from perceptron import NativePerceptron
import pennylane as qml
import pennylane.numpy as np
import jax
import jax.numpy as jnp
import optax
import jaxopt
from perceptron import NativePerceptron
import time 

Ntrials=100
N=4
P=5*N


# Configuration settings
jax.config.update("jax_enable_x64", True)
jax.config.update("jax_platform_name", "cpu")

# Setting up the quantum perceptron problem
perceptron_qubits = N
n_axis=2
pulse_basis = P
sigma=0.1
save_path = ''
n_epochs = 200

ts = jnp.array([1.0])
t = 1
times = jnp.linspace(0,t, pulse_basis+2)[1:-1]
dev = qml.device("default.qubit.jax", wires=perceptron_qubits)

#Setting up perceptron
perceptron = NativePerceptron(perceptron_qubits, pulse_basis, basis='gaussian', pulse_width=sigma, native_coupling=1)
H = perceptron.H

#Setting up target unitary
H_obj = perceptron.get_toy_model(0.1)
W = qml.matrix(qml.evolve(H_obj, coeff=1))

hcs = [qml.PauliX(n) for n in range(perceptron_qubits)]
hcs+= [qml.PauliY(n) for n in range(perceptron_qubits)]
# Defining the loss function
@jax.jit
def loss(param_vector):
    param_list = perceptron.vector_to_hamiltonian_parameters(param_vector)
    U = qml.matrix(qml.evolve(perceptron.H)(param_list, t))
    
    return qml.math.frobenius_inner_product(jnp.conjugate(U-W), U-W).real

random_seed = int(time.time() * 1000)  # time in milliseconds
param_vector = perceptron.get_random_parameter_vector(random_seed)

solver = jaxopt.LBFGS(loss,maxiter=1000)

res=solver.run(param_vector)

print('Final loss: ', res.state.value)
print('Max grad: ', np.max(res.state.grad))

"""
Nreps=5

schedule = optax.exponential_decay(0.1,n_epochs,0.1)
    
optimizer = optax.adam(learning_rate=schedule)

for j in range(Nreps):
        #param_vector = data["final_thetas"][ind]
        random_seed = int(time.time() * 1000)  # time in milliseconds
        param_vector = perceptron.get_random_parameter_vector(random_seed)
        opt_state = optimizer.init(param_vector)
        sub_losses = np.zeros([n_epochs])
        gradient_diffs = np.zeros([n_epochs])
        gradients_trajectory = []
        
        # Optimization loop
        for n in range(n_epochs):
            val, grads = jax.value_and_grad(loss)(param_vector)
            updates, opt_state = optimizer.update(grads, opt_state)

            sub_losses[n] = val
                
            gradients_trajectory.append(grads)
            if n > 0:
                gradient_diffs[n - 1] = jnp.linalg.norm(grads - gradients_trajectory[-2])
            param_vector = optax.apply_updates(param_vector, updates)

            if n % 1 == 0:  # Adjust the frequency of printing as needed
                print(f"Epoch {n+1}/{n_epochs}; loss: {val}")
                        
"""
                        